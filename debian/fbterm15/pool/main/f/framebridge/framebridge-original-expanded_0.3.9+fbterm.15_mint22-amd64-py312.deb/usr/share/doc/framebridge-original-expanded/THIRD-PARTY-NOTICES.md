# Included third-party notices

The assembled notices and license texts are included under
[licensing/third-party](licensing/third-party/THIRD-PARTY-NOTICES.md).
Original vendored notices are preserved with their components.
