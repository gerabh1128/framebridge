# Source availability for FrameBridge 0.3.9+fbterm.15

Matching corresponding source: FrameBridge-0.3.9+fbterm.15-source.tar.gz (SHA-256 b00ec2b7f05a3c365b8e35fa8fbeaa85054a1797169c13954a3dd8da052693a9).

The release source set also includes these separate assets:

- FrameBridge-0.3.1-Community-Preview1-dependency-sources.tar.gz
  Bytes: 82606998
  SHA-256: 64540a85bd65eac3f394d8c0a967cacbc00e112676d57d644dcd1bb691c1926a
- FrameBridge-0.3.1-tunnel-client-dependency-sources.tar.gz
  Bytes: 26941745
  SHA-256: 6445d4f0e773aba833fe5c610fbae54102b92de2ce636438f769f21e890c2bd9

The Preview1 name deliberately identifies an immutable shared asset.
Retain the R2 source-notice supplement under licensing/third-party.
The tunnel dependency asset records exact dependency archives and
retained notices; it does not assert an independently rebuilt tunnel
executable or an identified exact own-source revision.

See licensing/third-party/SOURCE-AVAILABILITY.md and both dependency
source indices for scope and provenance. Publication readiness and
signature status are external release records, not builder claims.
